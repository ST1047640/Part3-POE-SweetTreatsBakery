/* validation.js - PROFESSIONAL AND ACCESSIBLE VERSION */
document.addEventListener('DOMContentLoaded', function(){

    const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const ERROR_CLASS = 'is-invalid'; 

    // --- HELPER FUNCTIONS ---
    function displayError(field, message){
        // Finds or creates the dedicated error message div below the field
        let errorEl = field.parentNode.querySelector('.error-message');
        if(!errorEl){
            errorEl = document.createElement('div');
            errorEl.className = 'error-message';
            errorEl.id = field.id + '-error';
            field.parentNode.appendChild(errorEl);
        }
        
        field.classList.add(ERROR_CLASS); // Adds red border class
        field.setAttribute('aria-invalid', 'true');
        field.setAttribute('aria-describedby', errorEl.id);

        errorEl.textContent = message;
        errorEl.style.display = 'block';
        errorEl.setAttribute('role', 'alert'); // Important for screen readers
    }

    function clearError(field){
        const errorEl = document.getElementById(field.id + '-error');
        
        field.classList.remove(ERROR_CLASS);
        field.removeAttribute('aria-invalid');

        if(errorEl) {
            errorEl.textContent = '';
            errorEl.style.display = 'none';
            errorEl.removeAttribute('role');
            field.removeAttribute('aria-describedby');
        }
    }

    // Generic validation logic for cleaner form checks
    function validateField(field, condition, message) {
        clearError(field);
        if (condition) {
            displayError(field, message);
            return false;
        }
        return true;
    }

    // --- 1. CONTACT FORM (Validation before Mailto) ---
    const contactForm = document.getElementById('contactForm');
    if(contactForm){
        // Attach 'blur' listeners for immediate feedback as user leaves a field
        contactForm.elements.name.addEventListener('blur', function() { validateField(this, this.value.trim().length < 2, 'Name must be at least 2 characters.'); });
        
        contactForm.addEventListener('submit', function(e){
            e.preventDefault();
            
            const nameField = contactForm.elements.name;
            const emailField = contactForm.elements.email;
            const messageField = contactForm.elements.message;

            let isValid = true;
            
            // Re-validate all on submit
            isValid &= validateField(nameField, nameField.value.trim().length < 2, 'Name must be at least 2 characters.');
            isValid &= validateField(emailField, !EMAIL_REGEX.test(emailField.value.trim()), 'Please enter a valid email address.');
            isValid &= validateField(messageField, messageField.value.trim().length < 20, 'Message is too short. Please provide at least 20 characters.');

            if(isValid){
                // Existing mailto logic
                const recipient = 'info@sweettreatsbakery.com'; // Use a standard recipient here
                const mailBody = encodeURIComponent(`Name: ${nameField.value.trim()}\nEmail: ${emailField.value.trim()}\n\n${messageField.value.trim()}`);
                const mailSubj = encodeURIComponent(contactForm.elements.subject.value.trim() || 'General Website Enquiry');
                
                // Open mail client and show success message (since mailto leaves page)
                window.location.href = `mailto:${recipient}?subject=${mailSubj}&body=${mailBody}`;
                alert('Thank you! Your email is ready to send in your mail client.');
            }
        });
    }

    // --- 2. ENQUIRY FORM (AJAX Simulation & Cost Estimate) ---
    const enquiryForm = document.getElementById('enquiryForm');
    if(enquiryForm){
        enquiryForm.addEventListener('submit', function(e){
            e.preventDefault();
            
            const nameField = enquiryForm.elements.name;
            const emailField = enquiryForm.elements.email;
            const qtyField = enquiryForm.elements.quantity;

            let isValid = true;

            isValid &= validateField(nameField, nameField.value.trim().length < 2, 'Name too short.');
            isValid &= validateField(emailField, !EMAIL_REGEX.test(emailField.value.trim()), 'Invalid email format.');
            
            const qty = parseInt(qtyField.value, 10);
            isValid &= validateField(qtyField, qty <= 0, 'Quantity must be 1 or more.');

            if(isValid){
                simulateAjaxRequest(enquiryForm, qty);
            }
        });
    }

    // Simulates an asynchronous server request (AJAX requirement)
    function simulateAjaxRequest(form, qty) {
        const product = form.elements.product.value;
        const prices = { 'Chocolate Cake':250, 'Vanilla Cake':230, 'Red Velvet Cake':200, 
                         'Sourdough Loaf':45, 'Whole Wheat Bread':40, 'Butter Croissant':30 };
        
        const unit = prices[product] || 50;
        const total = unit * qty;
        const availability = (qty > 15) ? 'Limited stock. Allow 3 days lead time.' : 'Available for next-day pickup.';
        
        const resultBox = form.querySelector('.enquiry-result');
        const submitBtn = form.querySelector('button[type="submit"]');
        
        // Show loading state
        submitBtn.textContent = 'Calculating...';
        submitBtn.disabled = true;
        resultBox.innerHTML = '<p style="text-align:center;">Calculating estimate...</p>';
        resultBox.style.display = 'block';

        // Simulate network delay using setTimeout
        setTimeout(() => {
            submitBtn.textContent = 'Get an Estimate';
            submitBtn.disabled = false;
            
            resultBox.innerHTML = `
                <p style="color:#008000; font-weight:bold;">✅ Enquiry Successful!</p>
                <p><strong>Estimated Cost:</strong> R ${total.toFixed(2)}</p>
                <p><strong>Availability:</strong> ${availability}</p>
                <p style="font-size:0.9em; margin-top:8px;">We will contact you shortly to confirm the order.</p>
            `;
        }, 1200); // 1.2 second simulated delay
    }
});