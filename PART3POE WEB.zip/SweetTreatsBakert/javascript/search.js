/* search.js - product filter */
document.addEventListener('DOMContentLoaded', function(){
  const input = document.getElementById('product-search');
  if(!input) return;
  input.addEventListener('input', function(){
    const q = input.value.trim().toLowerCase();
    document.querySelectorAll('.product').forEach(card => {
      const name = (card.dataset.name || card.querySelector('h4')?.innerText || '').toLowerCase();
      card.style.display = name.includes(q) ? '' : 'none';
    });
  });
});
