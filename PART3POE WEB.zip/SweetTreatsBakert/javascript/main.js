/* main.js - interactive features */
document.addEventListener('DOMContentLoaded', function(){

  // LIGHTBOX: opens when a gallery image is clicked
  document.querySelectorAll('.gallery-grid img, .product img').forEach(img => {
    img.addEventListener('click', () => {
      openLightbox(img.src, img.alt || '');
    });
  });

  function openLightbox(src, alt){
    let lb = document.querySelector('.lightbox');
    if(!lb){
      lb = document.createElement('div');
      lb.className = 'lightbox';
      lb.innerHTML = `<img src="${src}" alt="${alt}"><button class="lb-close" aria-label="Close lightbox">×</button>`;
      document.body.appendChild(lb);
      lb.querySelector('.lb-close').addEventListener('click', closeLightbox);
      lb.addEventListener('click', (e) => { if(e.target === lb) closeLightbox(); });
    } else {
      lb.querySelector('img').src = src;
      lb.querySelector('img').alt = alt;
    }
    lb.classList.add('open');
  }

  function closeLightbox(){
    const lb = document.querySelector('.lightbox');
    if(lb) lb.classList.remove('open');
  }

// ACCORDION: Using CSS class toggle for smooth transition
document.querySelectorAll('.accordion-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const panel = btn.nextElementSibling;
    if(!panel) return;
    
    // Toggle the 'open' class on the panel (CRITICAL for CSS transition)
    panel.classList.toggle('open');
    btn.classList.toggle('open');
    
    // Accessibility update: aria-expanded
    const isExpanded = btn.getAttribute('aria-expanded') === 'true' || false;
    btn.setAttribute('aria-expanded', !isExpanded);
    // Call the map function to initialize the map when the page loads
    initializeContactMap(); 
}); // <--- Ensure you close the DOMContentLoaded bracket
  });

  /* Map Initialization Function */
function initializeContactMap() {
    const mapElement = document.getElementById('bakery-map');
    // Check if the map container exists on the current page
    if (!mapElement) return; 

    // Placeholder Coordinates for Johannesburg (Adjust to your exact location)
    const bakeryLocation = [-26.2041, 28.0473]; // Example: Near central Johannesburg

    const map = L.map('bakery-map').setView(bakeryLocation, 13); // '13' is the zoom level

    // Add the tile layer (the map tiles themselves)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Add a custom marker
    L.marker(bakeryLocation).addTo(map)
        .bindPopup('SweetTreats Bakery. Come Visit Us!')
        .openPopup();
}
});